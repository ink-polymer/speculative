# 双H20执行与AR加速比口径

日期：2026-09-16。这里区分部署、已完成执行、完整cell与正式认证。

## 服务器分工

|服务器入口|GPU与配置|分片|持久任务|
|---|---|---|---|
|region-42.seetacloud.com:42873|H20，97871 MiB，驱动580.65.06，功率上限500 W，标称最高SM1980 MHz/显存2619 MHz|Qwen3-4B及配套冻结DFlash|`dp-paper-4b-20260916`|
|region-42.seetacloud.com:54917|同型号、容量、驱动、功率上限和标称最高时钟|Qwen3-8B及配套冻结DFlash|`2619.dp-paper-8b-20260916`，23:22:03已启动|

两机GPU独立，不是一个模型做跨机tensor parallel。所有加速比在同一模型、同一服务器、匹配输入与随机种子下归一化，不借用另一机器的AR时间。

旧双模型队列在主阶段4B执行中作一次可恢复中断，2026-09-16 22:51:01恢复为4B专用分片。原队列在恢复前已经完成50个主阶段request groups，原始JSON及原日志保留；只重新执行尚未原子写出的组。8B在新机重新测量，不把旧机8B先导记录并入新机8B结果。

数据直传由旧机screen `dp-copy-8b-20260916` 执行，2026-09-16 22:48:35启动。复制旧Python环境、两套固定8B模型快照、已有数据和独立硬件校准。早先经过本地中转的慢速复制已停止；直传修复/补齐接收端文件。没有记录密码或私钥。

直传与旧机部分4B计时存在重叠，保留这一来源信息。两机仍各只有一个GPU实验进程。正式确认复现应在无额外部署负载时进行，当前结果是已注册共同框架batch研究，不因部署完成变成生产服务或严格无损证据。

## 启动核验与复现

`scripts/verify_dp_second_h20.py` 对两机全部 `src/**/*.py` 和 `scripts/*.py`、固定8B模型快照的全部文件计算SHA-256，比较已安装软件版本、Python、Torch、Torch CUDA构建和GPU标识。模型revision来自冻结配置。仅一致时自动启动新机8B任务，失败则停止并留下日志，不悄悄替换模型或依赖。

实际启动核验已通过：57个Python源文件、24个固定模型快照文件和软件/GPU身份均一致。最初一次核验拦截的是本地Mac打包上传生成的27个AppleDouble附带文件，真实Python文件没有任何changed或missing。全部27个文件逐一以file确认后移至 `/root/dp-upload-metadata-archive-20260916/`，可恢复，未改动真正源码。失败日志保留，不绕过校验。

23:22:29已看到新8B实际GPU进程、18821 MiB显存及58%采样时利用率，并写出首个GSM8K/T1/R193/C1/输出128、seed17配对组，包含AR/DF/DD/DP四种方法，外层执行时间之和5.619459秒。该单组是先导实测，不是完整主实验或任务质量认证。两机后续阶段仍运行中。

23:25:27新机8B先导全部8组已经完成（C1/4/16/32 × 输出128/512，共32个真实方法执行），主阶段8B进程PID2924已启动。旧机4B已经完成GSM8K/T1/R193/C1/输出256的全部32题×3seed×3计时，并继续C4。完整跨条件主表尚未完成。

新机Python3.11/Torch2.8实际环境中的97项CPU回归通过，16.48秒；独立有理数验证也通过，报告保存在 `CPU_THEORY_VALIDATION.json`。本地Python3.13 CPU回归97项通过，5.68秒。回归/有限有理数检查不称作真实GPU Target-law认证。新机CPU检查与pilot有短暂重叠，先导仍仅用于估时及诊断，主阶段在这些CPU检查完成后启动。

冻结DP核心SHA-256仍为 `3f132a41b659d1306cbfc3fbb348c0f89284d097d69851f0f73d8a6e4518587f`。本次没有修改核心、GPU研究驱动或分配控制实现；增加/调整的是理论、独立验证、部署分片和结果分析文件。

两机使用相同目录：

- 实验代码 `/root/dp-paper-study-20260916`。
- 原始结果 `/root/dp-paper-results-20260916`。
- Python `/root/autodl-tmp/envs/speculative/bin/python`。
- 新机部署报告 `/root/dp-paper-results-20260916/HOST_PROVENANCE.json`。
- 旧机直传日志 `/root/dp-paper-results-20260916/deploy-second-h20.log`。
- 单机执行日志 `queue-4b.log` 或 `queue-8b.log`。

任务序列为pilot、main、budget、ablation、temperature0、long_output、context、quality_math。screen拥有任务存续，关闭本地SSH不会主动结束它。每组原子写入，恢复仅跳过源和数据合同匹配的已完成组。

## 统一AR归一化

对同配置、逐一匹配的请求身份、prompt哈希、请求随机种子及repeat，定义

$$\operatorname{TPS}_m=\frac{\sum_jN_{m,j}}{\sum_jT_{m,j}},\qquad
\operatorname{Speedup}_{m/AR}=\frac{\operatorname{TPS}_m}{\operatorname{TPS}_{AR}}
=\frac{\sum_jN_{m,j}}{\sum_jN_{AR,j}}
\frac{\sum_jT_{AR,j}}{\sum_jT_{m,j}}.$$

AR固定为1.00×。长度完全相同时该定义退化为总耗时比；T=1输出长度可能不同，不能直接仅报告耗时比或平均单次倍率。

计时采用原始runner定义的解码wall区间，包括prefill及解码中Draft、Target验证、纠正/KV相关执行与同步；模型加载、输入编码和输出评分另计。AR为cached padded的Target-only解码，树方法为packed sequence；不用这一对比冒充相同物理几何或逐bit同输出。AR执行没有Draft计算，但共同加载的engine保留Draft权重，显存值按实际engine记录，不能把它称为纯AR最小显存。

所有方法列——AR、DDTree、DFlash、DP及消融——均展示AR归一化加速比与绝对tok/s。该总加速比包含基础speculative decoding收益，不能全部归因于DP；DP独立价值还需同路径、同候选的强equal/greedy对照和可选择轮次归因。

消融使用同机器、同模型主阶段的匹配AR记录，明确标为main-stage复用；不是消融组内交错AR计时。缺少完整匹配就显示pending，不借用其他条件。统计按request group聚类，保留其所有seed/repeat；少于8个独立group显示few警告，只有1个group不产生bootstrap区间。

## 输出与证据状态

每机结束分片后自动运行 `summarize_dp_paper_study.py`，生成 `RESULTS.md`、`RESULTS.json`，并按已测温度与预算生成 `RESULTS_T0_R*.md` 和 `RESULTS_T1_R*.md`。

每格显示执行数/预注册数与partial/complete。complete表示该格计划执行全部完成并匹配AR，不表示原生serving、任务质量或严格序列law已认证。没有产生的温度/并发/预算组合不补造数字。

本地进度快照保存在 `results/dual-h20-progress-20260916/`：`host-42873` 和 `host-54917` 分别保留来源；`combined`只读取旧机4B和新机8B，防止旧机8B先导重复计入。快照不是自动持续同步，须在刷新后报告其实际采集时点。

18项定理、异构收益方差下界、节点整数区间快速选择及联合入场扩展见 [DP_THEORY_JOURNAL.md](DP_THEORY_JOURNAL.md)。独立有限算术结果见 [DP_THEORY_JOURNAL_CHECKS.json](DP_THEORY_JOURNAL_CHECKS.json)。这些证明及CPU检查不替代真实GPU posterior认证；冻结BF16严格AR认证仍未通过，数学任务非劣性等待已注册质量阶段。
