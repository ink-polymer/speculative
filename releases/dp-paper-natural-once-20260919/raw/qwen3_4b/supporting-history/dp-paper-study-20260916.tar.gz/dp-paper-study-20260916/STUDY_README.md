# DP paper-study execution

Primary abstract: `paper/ABSTRACT_EN.md`. Full plan: `paper/EXPERIMENT_PLAN.md`.

This directory extends the frozen original DP release with isolated same-path controls and a resumable real-H20 batch-study driver. It does not alter the original server checkout or GitHub release. Additional study files are not part of the original frozen payload manifest; use the study contract/source hashes, not the original payload manifest, to certify new runs.

Server code: `/root/dp-paper-study-20260916`.

Server outputs: `/root/dp-paper-results-20260916`.

Persistent session: `screen -r dp-paper-20260916`.

Runner: `scripts/run_dp_paper_queue.sh`. Each completed request group is atomically recorded; resume skips only groups matching the same data and source contract. Errors/OOM stop the queue and are reported, not silently removed. No code-quality execution occurs as root. The final summarizer grades only mathematics after generation using the already-installed math_verify parser, with gold self-tests and prompt-cluster uncertainty.

Actual pilot timings and the planning estimate are separate from formal results. `formal_complete=false` until strict/numerical claims are resolved, native serving, official direct-related methods, safe code grading and larger independent groups are completed.

CPU validation of this extension: 94 tests passed (89 frozen regression +5 new driver/control/statistics tests), in5.81 seconds. It does not establish GPU speed. First failed startup logs are retained; successful pilot results come from the corrected AR posterior dtype script.

Disk housekeeping: five unrelated old RL tree-experience files (1,870,587,837 bytes) were moved, not deleted, from the old checkout data directory to `/root/dp-unrelated-archive-20260916/rl-tree-experience/`. Model weights, original DP code and result evidence were preserved.
