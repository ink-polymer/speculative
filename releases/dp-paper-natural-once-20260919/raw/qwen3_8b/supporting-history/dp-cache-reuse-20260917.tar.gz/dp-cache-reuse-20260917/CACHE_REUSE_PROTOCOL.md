# Incremental Draft KV reuse candidate — 2026-09-17

## Identity and preserved baseline

This is a separate implementation candidate, not a rewrite of the frozen paper study.
The frozen decoder in `../dp-paper-study-20260916` retains SHA-256
`3f132a41b659d1306cbfc3fbb348c0f89284d097d69851f0f73d8a6e4518587f`.
The cache candidate decoder SHA-256 is
`a7cd86d6c6835e65ea9f6dbc7b2801efcf0a28df601160ec4e75cc2bcffcec20`.
Each new experiment records complete source hashes. Historical measurements are
not imported into candidate tables, and candidate outputs are not written to old directories.

Both H20 servers were inspected. Their frozen study decoder is identical;
the older server's fast-state decoder has the same existing DDTree cache branch.
The study's `matched_specs` explicitly disabled that branch for all methods.
Thus there was no already-enabled DFlash cache implementation on the other study server to copy.

## Change

The existing request-local padded incremental Draft cache branch now also supports
DFlash. DFlash retains its parallel greedy chain rather than adopting DDTree's
probability tree. DP still uses canonical proposal masses and the unchanged
global heterogeneous-budget allocator.

The benchmark explicitly enables `reuse_request_draft_cache=True` for both
cached methods; uncached controls remain disabled. Only the newly committed
Target features are projected in later Draft rounds. Each request retains its
own context cache; right-padding rows and Draft noise rows are dropped before
the next round. Cache-prefix agreement is checked on every proposal.

The main cache ablation preserves serial speculative prefill, packed Target
verification, verifier, precision, budget options, and AR baseline. It does
not quietly attribute batch-prefill gains to caching. Optional batch prefill
requires a separate output directory and applies equally to both speculative
controls. Persistent Target KV was already enabled in the prior study;
this change does not remove full-prefix Target cache gathering or the dense
cross-request verification mask.

## Validation evidence

- Local CPU suite: 93 passed.
- First H20 CPU suite: 93 passed.
- Real H20 Draft audit: three ragged requests, three rounds, reordering,
  differing update lengths, both DFlash and DP proposal families.
- All audit logits finite; all Draft cache lengths agree with Target prefixes.
- First-round cached versus uncached logits agree exactly in this audit.
- Later rounds: maximum absolute logit difference 0.1875, maximum local
  total variation 0.03349870815873146; all audited greedy proposal paths agree.

These are bounded implementation checks, not certification of BF16 equality
to autoregressive decoding or a full-sequence distribution test. Proposal
numerical drift may alter DP choices or outputs; the benchmark records
cached/uncached output equality and within-method repeatability explicitly.

## Performance protocol

Temperature 1, global verification budget 193, BF16 SDPA, eager execution,
FP32 proposal/posterior, no compilation or CUDA graphs. Count output tokens
over synchronized decode wall time including prefill, Draft, KV packing,
Target verification and selection. Model loading and between-trial GC are
excluded equally. Report each method's speedup versus matched AR, plus
cached/uncached ratios as a separate cache contribution metric.

The first diagnostic runs 8192-token synthetic input, C=8, output cap 128,
seed 17 and one repetition. It is not a multi-seed formal result and must not
be presented as GSM8K accuracy. Follow-up matched cases use C=1/4/8,
synthetic context 128/8192, natural GSM8K and MATH500 prompts, seeds 17/29,
three repeats each. Aggregate throughput is total tokens / total wall time,
not an unweighted mean of trial throughput values. Only one request group
per dataset/concurrency is sampled in this diagnostic matrix; it is not a
full task-quality evaluation.

On the first server, the old quality-generation worker was stopped; completed
groups remain intact and an unfinished group is not treated as a result.
The cache-validation screen resumes the unchanged old study after its queue
finishes or fails. The second server's existing task remains uninterrupted.
